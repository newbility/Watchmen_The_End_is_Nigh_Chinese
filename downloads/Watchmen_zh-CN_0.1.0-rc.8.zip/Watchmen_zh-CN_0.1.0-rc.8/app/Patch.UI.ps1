﻿function Show-WatchmenPatchUi([string]$PackageRoot) {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [Windows.Forms.Application]::EnableVisualStyles()
    $form = New-Object Windows.Forms.Form
    $form.Text = '守望者：终结将至 · 简体中文补丁（候选测试版）'
    $form.ClientSize = New-Object Drawing.Size(800,620)
    $form.MinimumSize = New-Object Drawing.Size(816,659)
    $form.StartPosition = 'CenterScreen'
    $form.AutoScaleMode = 'Dpi'
    $form.Font = New-Object Drawing.Font('Microsoft YaHei UI',10)
    $form.BackColor = [Drawing.Color]::FromArgb(247,247,244)
    $form.Tag = $false
    $title = New-Object Windows.Forms.Label
    $title.Text = '守望者：终结将至'
    $title.Location = New-Object Drawing.Point(24,20)
    $title.Size = New-Object Drawing.Size(750,40)
    $title.Font = New-Object Drawing.Font('Microsoft YaHei UI',19,[Drawing.FontStyle]::Bold)
    $form.Controls.Add($title)
    $intro = New-Object Windows.Forms.Label
    $intro.Text = "第一部 · Steam 英文资源 · 简体中文 / 思源黑体`r`n候选测试版：尚未完成全关卡与清洁系统验收。"
    $intro.Location = New-Object Drawing.Point(24,68)
    $intro.Size = New-Object Drawing.Size(750,52)
    $intro.Anchor = 'Top,Left,Right'
    $form.Controls.Add($intro)
    $directoryLabel = New-Object Windows.Forms.Label
    $directoryLabel.Text = '游戏根目录（包含 data 与 derived_pc）'
    $directoryLabel.Location = New-Object Drawing.Point(24,134)
    $directoryLabel.Size = New-Object Drawing.Size(650,25)
    $form.Controls.Add($directoryLabel)
    $directory = New-Object Windows.Forms.TextBox
    $directory.Location = New-Object Drawing.Point(24,164)
    $directory.Size = New-Object Drawing.Size(620,30)
    $directory.Anchor = 'Top,Left,Right'
    $directory.AccessibleName = '游戏根目录'
    $directory.TabIndex = 0
    $form.Controls.Add($directory)
    $browse = New-Object Windows.Forms.Button
    $browse.Text = '选择目录…'
    $browse.Location = New-Object Drawing.Point(656,160)
    $browse.Size = New-Object Drawing.Size(120,40)
    $browse.Anchor = 'Top,Right'
    $browse.TabIndex = 1
    $form.Controls.Add($browse)
    $details = New-Object Windows.Forms.TextBox
    $details.Multiline = $true
    $details.ReadOnly = $true
    $details.ScrollBars = 'Vertical'
    $details.Location = New-Object Drawing.Point(24,214)
    $details.Size = New-Object Drawing.Size(752,154)
    $details.Anchor = 'Top,Left,Right'
    $details.AccessibleName = '目标文件及原件备份位置'
    $details.TabIndex = 2
    $form.Controls.Add($details)
    $buttons = @()
    $labels = @('检查所选目录','安装中文补丁','校验中文 / 原件','恢复本次原件')
    $actions = @('Inspect','Install','Verify','Restore')
    for ($i=0;$i -lt 4;$i++) {
        $button = New-Object Windows.Forms.Button
        $button.Text = $labels[$i]
        $button.Tag = $actions[$i]
        $button.Location = New-Object Drawing.Point((24+190*$i),384)
        $button.Size = New-Object Drawing.Size(180,46)
        $button.TabIndex = 3+$i
        $form.Controls.Add($button)
        $buttons += $button
    }
    $buttons[1].BackColor = [Drawing.Color]::FromArgb(247,210,44)
    $buttons[1].UseVisualStyleBackColor = $false
    $status = New-Object Windows.Forms.TextBox
    $status.Multiline = $true
    $status.ReadOnly = $true
    $status.ScrollBars = 'Vertical'
    $status.Location = New-Object Drawing.Point(24,448)
    $status.Size = New-Object Drawing.Size(752,145)
    $status.Anchor = 'Top,Bottom,Left,Right'
    $status.AccessibleName = '操作结果与错误说明'
    $status.TabIndex = 7
    $status.Text = '请选择游戏根目录。仅替换一个资源文件；原件备份保留在所选游戏目录中。'
    $form.Controls.Add($status)
    $refresh = {
        $details.Text = "修改文件：derived_pc\Levels\Game_Levels\WatchMen.block_h_z`r`n备份：请选择游戏目录后查看。`r`n恢复：只使用本次安装保存并通过校验的原件。"
        if ($directory.Text.Trim()) {
            try {
                $resolved = Assert-PlainPath $directory.Text.Trim()
                $details.Text = "目标目录：$resolved`r`n修改文件：$resolved\derived_pc\Levels\Game_Levels\WatchMen.block_h_z`r`n原件备份：$resolved\.watchmen-zh-cn\backups\original\WatchMen.block_h_z`r`n恢复目标：上方同一资源文件。"
            } catch { $status.Text = $_.Exception.Message }
        }
    }.GetNewClosure()
    $directory.Add_TextChanged($refresh)
    & $refresh
    $browse.Add_Click({
        $picker = New-Object Windows.Forms.FolderBrowserDialog
        $picker.Description = '选择第一部游戏根目录（包含 data 与 derived_pc）'
        $picker.ShowNewFolderButton = $false
        try {
            if ([IO.Directory]::Exists($directory.Text)) { $picker.SelectedPath=$directory.Text }
            if ($picker.ShowDialog($form) -eq [Windows.Forms.DialogResult]::OK) { $directory.Text=$picker.SelectedPath }
        } finally { $picker.Dispose() }
    }.GetNewClosure())
    $handler = {
        param($sender,$eventArgs)
        if ($form.Tag) { return }
        $action = [string]$sender.Tag
        try {
            $manifest = Get-PatchManifest $PackageRoot
            $state = Get-GamePatchState $directory.Text.Trim() $manifest
            if ($action -in @('Install','Restore')) {
                $verb = if($action -eq 'Install'){'安装中文补丁'}else{'恢复本次安装的原件'}
                $answer = [Windows.Forms.MessageBox]::Show($form,"$verb`r`n`r`n$($details.Text)`r`n`r`n请先退出游戏和启动器。是否执行？",$verb,'YesNo','Question','Button2')
                if ($answer -ne [Windows.Forms.DialogResult]::Yes) { return }
            }
            $form.Tag=$true
            foreach($b in $buttons){$b.Enabled=$false};$browse.Enabled=$false;$directory.Enabled=$false
            $status.Text='正在校验并执行，请等待。'
            $form.Refresh()
            $result = Invoke-WatchmenPatch $PackageRoot $directory.Text.Trim() $action
            $status.Text = $result.message+"`r`n目标："+$directory.Text+"`r`n备份："+$result.backup
        } catch { $status.Text='操作未完成：'+$_.Exception.Message }
        finally {
            foreach($b in $buttons){$b.Enabled=$true};$browse.Enabled=$true;$directory.Enabled=$true;$form.Tag=$false
        }
    }.GetNewClosure()
    foreach($button in $buttons){$button.Add_Click($handler)}
    $form.Add_FormClosing({param($sender,$e) if($sender.Tag){$e.Cancel=$true}})
    try { [void]$form.ShowDialog() } finally { $form.Dispose() }
}
