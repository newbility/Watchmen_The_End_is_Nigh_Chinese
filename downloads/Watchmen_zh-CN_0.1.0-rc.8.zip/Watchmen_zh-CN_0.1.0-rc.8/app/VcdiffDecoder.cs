// Project-owned VCDIFF default-table decoder; specification: RFC3284.
// Restricted profile: no custom tables, application headers or secondary compression.
// Includes xdelta's per-window big-endian Adler32 extension; outer SHA256 is mandatory.
using System;
using System.IO;

internal static class WatchmenVcdiff
{
    const int Limit = 64 * 1024 * 1024;
    struct Instruction {
        public int Kind, Size, Mode;
        public Instruction(int kind, int size, int mode) { Kind=kind; Size=size; Mode=mode; }
    }
    static readonly Instruction[,] Table = MakeTable();
    static Instruction[,] MakeTable() {
        var t = new Instruction[256,2]; int c=0;
        t[c++,0]=new Instruction(1,0,0); // RUN
        t[c++,0]=new Instruction(2,0,0); // ADD
        for(int s=1;s<=17;s++) t[c++,0]=new Instruction(2,s,0);
        for(int m=0;m<9;m++) {
            t[c++,0]=new Instruction(3,0,m); // COPY, dynamic size
            for(int s=4;s<=18;s++) t[c++,0]=new Instruction(3,s,m);
        }
        for(int m=0;m<6;m++) for(int a=1;a<=4;a++) for(int s=4;s<=6;s++) {
            t[c,0]=new Instruction(2,a,0); t[c++,1]=new Instruction(3,s,m);
        }
        for(int m=6;m<9;m++) for(int a=1;a<=4;a++) {
            t[c,0]=new Instruction(2,a,0); t[c++,1]=new Instruction(3,4,m);
        }
        for(int m=0;m<9;m++) {
            t[c,0]=new Instruction(3,4,m); t[c++,1]=new Instruction(2,1,0);
        }
        Check(c==256,"Invalid default table"); return t;
    }
    static void Check(bool ok, string message) { if(!ok) throw new InvalidDataException(message); }
    static int Byte(byte[] b, ref int p, int end) {
        Check(p>=0 && p<end && end<=b.Length,"Truncated VCDIFF section"); return b[p++];
    }
    static int Number(byte[] b, ref int p, int end) {
        long n=0;
        for(int i=0;i<5;i++) {
            int v=Byte(b,ref p,end); n=(n<<7)|(uint)(v&127);
            Check(n<=Int32.MaxValue,"VCDIFF integer overflow");
            if((v&128)==0) return (int)n;
        }
        throw new InvalidDataException("Overlong VCDIFF integer");
    }
    static int End(int offset,int length,int limit) {
        Check(length>=0 && offset>=0 && offset<=limit && length<=limit-offset,"VCDIFF range outside section");
        return offset+length;
    }
    static uint Adler(byte[] b) {
        uint a=1,s=0;
        for(int i=0;i<b.Length;i++) { a=(a+b[i])%65521; s=(s+a)%65521; }
        return (s<<16)|a;
    }
    public static byte[] Decode(byte[] source,byte[] delta) {
        Check(source.Length<=Limit && delta.Length<=Limit,"Input exceeds decoder limit");
        int p=0;
        Check(Byte(delta,ref p,delta.Length)==0xD6 && Byte(delta,ref p,delta.Length)==0xC3 &&
              Byte(delta,ref p,delta.Length)==0xC4 && Byte(delta,ref p,delta.Length)==0,"Invalid VCDIFF magic/version");
        Check(Byte(delta,ref p,delta.Length)==0,"Unsupported VCDIFF header features");
        using(var output=new MemoryStream()) {
            while(p<delta.Length) {
                int flag=Byte(delta,ref p,delta.Length);
                Check((flag&~7)==0 && (flag&3)!=3,"Invalid window indicator");
                int sourceLength=0,sourceOffset=0;
                byte[] windowSource=source;
                if((flag&3)!=0) {
                    sourceLength=Number(delta,ref p,delta.Length); sourceOffset=Number(delta,ref p,delta.Length);
                    if((flag&2)!=0) windowSource=output.ToArray();
                    End(sourceOffset,sourceLength,windowSource.Length);
                }
                int encodedLength=Number(delta,ref p,delta.Length);
                int windowEnd=End(p,encodedLength,delta.Length);
                int targetLength=Number(delta,ref p,windowEnd);
                Check(targetLength<=Limit-output.Length,"Output exceeds decoder limit");
                Check(Byte(delta,ref p,windowEnd)==0,"Secondary compression is not supported");
                int dataLength=Number(delta,ref p,windowEnd), instLength=Number(delta,ref p,windowEnd), addrLength=Number(delta,ref p,windowEnd);
                uint expectedAdler=0;
                if((flag&4)!=0) for(int i=0;i<4;i++) expectedAdler=(expectedAdler<<8)|(uint)Byte(delta,ref p,windowEnd);
                int dataPos=p, dataEnd=End(p,dataLength,windowEnd);
                int instPos=dataEnd, instEnd=End(instPos,instLength,windowEnd);
                int addrPos=instEnd, addrEnd=End(addrPos,addrLength,windowEnd);
                Check(addrEnd==windowEnd,"Inconsistent VCDIFF section lengths");
                byte[] target=new byte[targetLength]; int produced=0,nextNear=0;
                int[] near=new int[4], same=new int[768];
                while(instPos<instEnd) {
                    int code=Byte(delta,ref instPos,instEnd);
                    for(int half=0;half<2;half++) {
                        Instruction op=Table[code,half]; if(op.Kind==0) continue;
                        int size=op.Size==0 ? Number(delta,ref instPos,instEnd) : op.Size;
                        End(produced,size,targetLength);
                        if(op.Kind==1) {
                            byte value=(byte)Byte(delta,ref dataPos,dataEnd);
                            for(int i=0;i<size;i++) target[produced++]=value;
                        } else if(op.Kind==2) {
                            End(dataPos,size,dataEnd);
                            Buffer.BlockCopy(delta,dataPos,target,produced,size); dataPos+=size;produced+=size;
                        } else {
                            int address;
                            if(op.Mode<6) {
                                int encoded=Number(delta,ref addrPos,addrEnd);
                                if(op.Mode==0) address=encoded;
                                else if(op.Mode==1) address=sourceLength+produced-encoded;
                                else {
                                    Check(encoded<=Int32.MaxValue-near[op.Mode-2],"Address overflow");
                                    address=near[op.Mode-2]+encoded;
                                }
                            } else address=same[(op.Mode-6)*256+Byte(delta,ref addrPos,addrEnd)];
                            Check(address>=0 && address<sourceLength+produced,"Invalid COPY address");
                            Check(address>=sourceLength || size<=sourceLength-address,"COPY crosses source boundary");
                            near[nextNear]=address; nextNear=(nextNear+1)%4; same[address%768]=address;
                            for(int i=0;i<size;i++) {
                                int at=address+i;
                                if(at<sourceLength) target[produced++]=windowSource[sourceOffset+at];
                                else { int local=at-sourceLength; Check(local<produced,"COPY reads unwritten output"); target[produced++]=target[local]; }
                            }
                        }
                    }
                }
                Check(produced==targetLength && dataPos==dataEnd && addrPos==addrEnd,"Unconsumed or missing VCDIFF data");
                if((flag&4)!=0) Check(Adler(target)==expectedAdler,"Target Adler32 checksum mismatch");
                output.Write(target,0,target.Length);p=windowEnd;
            }
            return output.ToArray();
        }
    }
    public static int Main(string[] args) {
        try {
            Check(args.Length==3,"Usage: WatchmenDelta.exe source delta output");
            Check(new FileInfo(args[0]).Length<=Limit && new FileInfo(args[1]).Length<=Limit,"Input exceeds decoder limit");
            byte[] result=Decode(File.ReadAllBytes(args[0]),File.ReadAllBytes(args[1]));
            using(var file=new FileStream(args[2],FileMode.CreateNew,FileAccess.Write,FileShare.None)) { file.Write(result,0,result.Length);file.Flush(true); }
            return 0;
        } catch(Exception e) { Console.Error.WriteLine(e.Message);return 1; }
    }
}
