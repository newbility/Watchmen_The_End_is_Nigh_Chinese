﻿param(
    [string]$GameDirectory,
    [ValidateSet('Inspect','Install','Verify','Restore')][string]$Action = 'Inspect',
    [switch]$NoGui
)
$ErrorActionPreference = 'Stop'
# Use only this Windows PowerShell process's built-in modules, even when a
# PowerShell7 host has passed an incompatible PSModulePath through its environment.
$env:PSModulePath = Join-Path $PSHOME 'Modules'
$packageRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $PSScriptRoot 'Patch.Core.ps1')
if ($NoGui) {
    [Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
    try {
        if (-not $GameDirectory) { throw '必须指定游戏根目录。' }
        Invoke-WatchmenPatch $packageRoot $GameDirectory $Action | ConvertTo-Json -Depth 10
        exit 0
    } catch {
        [ordered]@{ok=$false;action=$Action;error=$_.Exception.Message} | ConvertTo-Json
        exit 1
    }
}
. (Join-Path $PSScriptRoot 'Patch.UI.ps1')
Show-WatchmenPatchUi $packageRoot
