﻿# Requires Windows PowerShell 5.1, included with supported Windows 10/11 systems.
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$script:TargetRelative = 'derived_pc/Levels/Game_Levels/WatchMen.block_h_z'
$script:BackupRelative = '.watchmen-zh-cn/backups/original/WatchMen.block_h_z'
$script:ReceiptRelative = '.watchmen-zh-cn/installation.json'
function Get-PatchHash([string]$Path) {
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}
function Assert-PlainPath([string]$Path) {
    $full = [IO.Path]::GetFullPath($Path)
    if ($full.StartsWith('\\')) { throw '请选择本机磁盘中的游戏目录。' }
    $walk = $full
    while ($walk) {
        if (Test-Path -LiteralPath $walk) {
            if ((Get-Item -LiteralPath $walk -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {
                throw "路径含目录链接或重解析点，未执行操作：$walk"
            }
        }
        $parent = [IO.Path]::GetDirectoryName($walk)
        if ($parent -eq $walk) { break }
        $walk = $parent
    }
    $full
}
function Get-PatchPath([string]$Root, [string]$Relative) {
    if (-not $Relative -or [IO.Path]::IsPathRooted($Relative) -or $Relative.Contains(':')) { throw '无效的包内路径。' }
    $rootFull = [IO.Path]::GetFullPath($Root).TrimEnd('\','/')
    $full = [IO.Path]::GetFullPath((Join-Path $rootFull $Relative))
    if (-not $full.StartsWith($rootFull+'\', [StringComparison]::OrdinalIgnoreCase)) { throw '路径超出所选目录。' }
    Assert-PlainPath $full
}
function Read-PatchJson([string]$Path) {
    Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
}
function Write-PatchJson([string]$Path, $Value) {
    $tmp = $Path+'.'+[Guid]::NewGuid().ToString('N')+'.tmp'
    try {
        [IO.File]::WriteAllText($tmp, ($Value | ConvertTo-Json -Depth 12)+[Environment]::NewLine, [Text.UTF8Encoding]::new($false))
        if ([IO.File]::Exists($Path)) { [IO.File]::Replace($tmp,$Path,[System.Management.Automation.Language.NullString]::Value) }
        else { [IO.File]::Move($tmp,$Path) }
    } finally { if ([IO.File]::Exists($tmp)) { [IO.File]::Delete($tmp) } }
}
function Get-PatchManifest([string]$PackageRoot) {
    $manifest = Read-PatchJson (Get-PatchPath $PackageRoot 'manifest.json')
    if ($manifest.schema -ne 1 -or $manifest.project -ne 'watchmen-part1-zh-CN' -or $manifest.appid -ne '21010' -or
        $manifest.target.relative_path -cne $script:TargetRelative -or $manifest.target.original_sha256 -ne '5cf62f057cc29d03677236d12ebbda7bda8e7d72f2ec7c786b9b32d27b395c07') {
        throw '补丁清单不属于此版本的守望者第一部。'
    }
    foreach ($entry in $manifest.files.PSObject.Properties) {
        $path = Get-PatchPath $PackageRoot $entry.Name
        if (-not [IO.File]::Exists($path) -or (Get-PatchHash $path) -ne $entry.Value.sha256 -or
            (Get-Item -LiteralPath $path).Length -ne $entry.Value.size) { throw "补丁包文件缺失或损坏：$($entry.Name)" }
    }
    $manifest
}
function Get-GamePatchState([string]$GameDirectory, $Manifest) {
    if ([string]::IsNullOrWhiteSpace($GameDirectory)) { throw '请先选择游戏根目录。' }
    $root = Assert-PlainPath $GameDirectory
    if (-not [IO.Directory]::Exists($root)) { throw '所选游戏目录不存在。' }
    foreach ($entry in $Manifest.game_fingerprints.PSObject.Properties) {
        $file = Get-PatchPath $root $entry.Name
        if (-not [IO.File]::Exists($file) -or (Get-PatchHash $file) -ne $entry.Value.sha256) {
            throw "游戏文件缺失、版本不同或已有修改：$($entry.Name)。请选择第一部游戏根目录。"
        }
    }
    $target = Get-PatchPath $root $script:TargetRelative
    $hash = Get-PatchHash $target
    if ($hash -eq $Manifest.target.original_sha256) { $state='original' }
    elseif ($hash -eq $Manifest.target.patched_sha256) { $state='installed' }
    else { throw '目标资源为未知版本或其他修改，已停止；不会覆盖现有内容。' }
    $backup = Get-PatchPath $root $script:BackupRelative
    $receiptPath = Get-PatchPath $root $script:ReceiptRelative
    $receipt = $null
    if ([IO.File]::Exists($receiptPath)) {
        $receipt = Read-PatchJson $receiptPath
        if ($receipt.schema -ne 1 -or $receipt.project -ne $Manifest.project -or
            $receipt.original_sha256 -ne $Manifest.target.original_sha256 -or $receipt.patched_sha256 -ne $Manifest.target.patched_sha256 -or
            $receipt.target -cne $script:TargetRelative -or $receipt.backup -cne $script:BackupRelative -or
            $receipt.status -notin @('prepared','installed','restore-prepared','restored')) { throw '安装记录与补丁不匹配，未执行写入。' }
        if (-not [IO.File]::Exists($backup)) { throw '安装记录对应的原件备份缺失，未执行写入。' }
    }
    if ([IO.File]::Exists($backup) -and (Get-PatchHash $backup) -ne $Manifest.target.original_sha256) {
        throw '原件备份损坏或不匹配，未执行写入；请保留现场与日志。'
    }
    [pscustomobject]@{root=$root;target=$target;backup=$backup;receipt_path=$receiptPath;receipt=$receipt;state=$state;sha256=$hash}
}
function Copy-PatchFileNew([string]$Source, [string]$Destination) {
    $inputFile = [IO.File]::Open($Source,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
    try {
        $outputFile = [IO.File]::Open($Destination,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
        try { $inputFile.CopyTo($outputFile); $outputFile.Flush($true) } finally { $outputFile.Dispose() }
    } finally { $inputFile.Dispose() }
}
function Invoke-PatchDecoder([string]$PackageRoot, [string]$Source, [string]$Output) {
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = Get-PatchPath $PackageRoot 'tools/WatchmenDelta.exe'
    $delta = Get-PatchPath $PackageRoot 'payload/watchmen-zh-CN.vcdiff'
    # All operands are filesystem paths (Windows filenames cannot contain quotes).
    $start.Arguments = '"'+$Source+'" "'+$delta+'" "'+$Output+'"'
    $start.WorkingDirectory = $PackageRoot
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardError = $true
    $start.EnvironmentVariables.Remove('XDELTA')
    $process = [Diagnostics.Process]::Start($start)
    try {
        $stderrTask = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit(120000)) { $process.Kill(); $process.WaitForExit(); throw '补丁解码超时；原件备份已保留。' }
        $stderr = $stderrTask.Result
        if ($process.ExitCode -ne 0) { throw "补丁解码失败（$($process.ExitCode)）：$stderr" }
    } finally { $process.Dispose() }
}
function Invoke-WatchmenPatch([string]$PackageRoot, [string]$GameDirectory, [ValidateSet('Inspect','Install','Verify','Restore')][string]$Action) {
    $manifest = Get-PatchManifest $PackageRoot
    $state = Get-GamePatchState $GameDirectory $manifest
    if ($Action -in @('Inspect','Verify')) {
        $restorable = ($null -ne $state.receipt -and [IO.File]::Exists($state.backup))
        $message = if ($state.state -eq 'original') {'原版资源校验通过。'} elseif ($restorable) {'中文资源与原件备份校验通过。'} else {'中文资源校验通过，但缺少本次安装记录和备份，无法恢复。'}
        return [ordered]@{ok=$true;action=$Action;state=$state.state;message=$message;game_directory=$state.root;target=$state.target;backup=$state.backup;restorable=$restorable;sha256=$state.sha256}
    }
    if (@(Get-Process -Name KapowMulti,MultiLauncher -ErrorAction SilentlyContinue).Count) { throw '请先退出守望者游戏及分辨率启动器，再安装或恢复。' }
    if ($state.state -eq 'installed' -and $null -eq $state.receipt) { throw '检测到中文资源，但没有对应安装记录，不能重新备份或恢复；请先找回原备份。' }
    if ($Action -eq 'Restore' -and $null -eq $state.receipt) { throw '未找到本次安装的原件备份记录；未修改游戏。' }
    $stateDir = Get-PatchPath $state.root '.watchmen-zh-cn'
    [void][IO.Directory]::CreateDirectory($stateDir)
    $lockPath = Get-PatchPath $state.root '.watchmen-zh-cn/operation.lock'
    $operationLock = [IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $tmp = $null
    try {
        # Re-read after taking the lock; a second instance may have completed first.
        $state = Get-GamePatchState $GameDirectory $manifest
        $record = [ordered]@{schema=1;project=$manifest.project;version=$manifest.version;target=$script:TargetRelative;backup=$script:BackupRelative;original_sha256=$manifest.target.original_sha256;patched_sha256=$manifest.target.patched_sha256;status='prepared';utc=[DateTime]::UtcNow.ToString('o')}
        if ($Action -eq 'Install') {
            if ($state.state -eq 'installed') {
                $record.status='installed'; Write-PatchJson $state.receipt_path $record
                return [ordered]@{ok=$true;action=$Action;state='installed';message='已安装当前版本，资源与备份一致，无需重复打补丁。';backup=$state.backup;game_directory=$state.root}
            }
            [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($state.backup))
            if (-not [IO.File]::Exists($state.backup)) {
                $backupTmp = $state.backup+'.'+[Guid]::NewGuid().ToString('N')+'.tmp'
                try {
                    Copy-PatchFileNew $state.target $backupTmp
                    if ((Get-PatchHash $backupTmp) -ne $manifest.target.original_sha256) { throw '原文件在备份期间改变，已停止。' }
                    [IO.File]::Move($backupTmp,$state.backup)
                } finally { if ([IO.File]::Exists($backupTmp)) { [IO.File]::Delete($backupTmp) } }
            }
            Write-PatchJson $state.receipt_path $record
            $tmp = Get-PatchPath $state.root ('.watchmen-zh-cn/decoded-'+[Guid]::NewGuid().ToString('N')+'.tmp')
            Invoke-PatchDecoder $PackageRoot $state.backup $tmp
            $expected = $manifest.target.patched_sha256
        } else {
            if ($state.state -eq 'original') {
                $record.status='restored'; Write-PatchJson $state.receipt_path $record
                return [ordered]@{ok=$true;action=$Action;state='original';message='原版资源已恢复，备份继续保留。';backup=$state.backup;game_directory=$state.root}
            }
            $record.status='restore-prepared'; Write-PatchJson $state.receipt_path $record
            $tmp = Get-PatchPath $state.root ('.watchmen-zh-cn/restored-'+[Guid]::NewGuid().ToString('N')+'.tmp')
            Copy-PatchFileNew $state.backup $tmp
            $expected = $manifest.target.original_sha256
        }
        if ((Get-PatchHash $tmp) -ne $expected) { throw '临时产物校验失败，游戏资源未替换。' }
        if ((Get-PatchHash $state.target) -ne $state.sha256) { throw '目标资源在操作期间改变，已停止；备份保留。' }
        [IO.File]::Replace($tmp,$state.target,[System.Management.Automation.Language.NullString]::Value)
        $tmp = $null
        if ((Get-PatchHash $state.target) -ne $expected) { throw '写入后校验失败；原件备份和预备记录保留，请保留现场。' }
        $record.status = if ($Action -eq 'Install') {'installed'} else {'restored'}
        Write-PatchJson $state.receipt_path $record
        [ordered]@{ok=$true;action=$Action;state=$record.status;message=$(if($Action -eq 'Install'){'安装完成，中文资源及原件备份校验通过。'}else{'已从本次安装的原件备份恢复，字节校验通过。'});game_directory=$state.root;backup=$state.backup;sha256=$expected}
    } finally {
        if ($tmp -and [IO.File]::Exists($tmp)) { [IO.File]::Delete($tmp) }
        $operationLock.Dispose()
    }
}
